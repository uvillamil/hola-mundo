import React, {Component} from 'react';

const ContactoF = ({nombre, apellido, email, conectado}) => (
  <div>
    <h1> nombre: { nombre } </h1>
    <h2> apellido: { apellido } </h2>
    <h3> email: { email } </h3>
    <h4> conectado: { conectado ? "Contacto En Línea" : "Contacto No Disponible"} </h4>
  </div>
);

class Contacto extends Component {

  constructor({nombre, apellido, email}) {
    super();
    this.state = { conectado: true };
    this.conectar = this.conectar.bind(this);
    this.desconectar = this.desconectar.bind(this);
  }

  conectar = () => {
    this.setState((state) => {
      return {...state, conectado: true}
    });
  }

  desconectar = () => {
    this.setState((state) => {
      return {...state, conectado: false}
    });
  }
  
  render() {
    return (
      <div>
        <button onClick={this.conectar}>Conectar</button>
        <button onClick={this.desconectar}>Desconectar</button>
        <ContactoF
          {...this.props}
          conectado= {this.state.conectado}
        />
      </div>
    );
  }
}

export default function App() {
  return (
    <Contacto
      nombre="Uriel"
      apellido="Villamil"
      email="uvillamil@gmail.com"
    />
  );
}
