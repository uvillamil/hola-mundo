

class Contacto {
    nombre;
    apellido;
    email;
  
    constructor(nombre, apellido, email) {
      this.nombre = nombre;
      this.apellido = apellido;
      this.email = email;
    }
  }
  
  export default Contacto;